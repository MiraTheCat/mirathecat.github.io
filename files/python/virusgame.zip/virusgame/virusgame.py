import pygame, math, random
pygame.init()
clock = pygame.time.Clock()
width = 800
height = 608
screen = pygame.display.set_mode((width, height)) # Setter opp vinduet
running = True
gameover = False
done = False
levelnumber = 0

dispensersound = pygame.mixer.Sound('dispenser.wav')
playerdead = pygame.mixer.Sound('kill.wav')
virusdead = pygame.mixer.Sound('viruskill.wav')

Levels = [
        [[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,9,9,1,1],
         [1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1],
         [1,0,8,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,2,0,1,0,0,0,1],
         [1,0,0,0,0,1,0,0,1,1,1,1,0,0,1,1,1,1,0,0,1,1,0,0,1],
         [1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,1],
         [1,1,1,0,0,1,0,0,0,0,0,0,0,0,0,4,0,1,0,0,0,1,0,0,1],
         [1,0,0,0,0,1,0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,1],
         [1,0,0,2,0,1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
         [1,4,0,0,0,1,0,0,1,0,4,0,0,0,0,0,0,0,0,0,0,1,0,0,1],
         [1,0,0,1,1,1,0,0,1,0,0,0,0,0,0,1,1,1,1,0,0,1,0,0,1],
         [1,0,0,0,0,1,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,1],
         [1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,1],
         [1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,1,1,1,1,0,0,1],
         [1,0,0,0,0,0,0,0,1,0,0,0,0,4,0,1,0,0,0,0,0,0,4,0,1],
         [1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1],
         [1,0,0,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1],
         [1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
         [1,0,0,4,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,0,2,1],
         [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]],

        [[1,1,1,1,1,1,9,9,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
         [1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
         [1,2,0,0,0,1,0,0,0,0,0,0,0,0,0,0,4,0,0,0,0,0,0,0,1],
         [1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,1],
         [1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,1],
         [1,0,1,1,1,1,0,0,0,0,0,0,0,0,4,0,0,1,0,0,0,1,0,0,1],
         [1,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,0,0,0,1],
         [1,1,1,1,1,0,0,1,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1],
         [1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,4,0,1,0,0,1,0,0,1],
         [1,0,4,0,0,0,0,0,1,0,0,0,0,1,1,1,1,1,1,0,0,1,4,0,1],
         [1,1,1,0,0,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,0,0,1],
         [1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,1,0,2,1],
         [1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,1,1,1,1,1,1,1,1],
         [1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1],
         [1,0,0,0,0,4,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,2,1],
         [1,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1],
         [1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
         [1,0,0,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
         [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,8,1,1]],
        
        [[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
         [1,0,4,0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,1,1,1,1,1,2,1],
         [1,0,0,0,0,0,0,0,0,0,4,0,1,0,1,0,1,0,0,0,0,0,0,0,1],
         [1,0,1,1,1,1,1,1,1,1,0,0,1,0,1,0,1,4,1,1,1,1,1,1,1],
         [1,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,1,0,0,0,0,0,9],
         [1,0,1,0,1,1,1,1,1,1,1,1,1,0,1,0,1,0,1,0,1,1,1,1,1],
         [1,0,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,1],
         [1,0,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,0,1],
         [1,0,0,0,0,1,0,0,0,1,0,1,0,0,0,0,0,1,0,0,0,1,1,0,1],
         [1,0,0,1,0,1,0,1,0,1,0,1,0,1,1,1,0,1,0,1,0,0,0,0,1],
         [1,0,0,1,0,1,0,1,0,1,0,1,0,0,0,1,0,1,0,1,1,1,1,0,1],
         [1,0,0,1,4,1,0,1,0,1,0,1,1,1,0,1,0,1,0,0,0,0,1,0,1],
         [1,0,0,1,0,1,0,1,0,1,0,1,0,0,0,1,0,1,1,1,1,4,1,0,1],
         [1,0,0,1,0,1,0,1,0,1,0,1,0,1,1,1,0,1,1,1,1,0,1,0,1],
         [1,0,0,1,0,0,0,1,0,1,0,1,0,0,0,1,0,0,0,0,0,0,1,0,1],
         [1,0,0,1,1,1,1,1,0,1,0,1,1,1,0,1,0,1,1,1,1,1,1,0,1],
         [1,0,0,0,0,1,0,0,0,1,0,1,1,1,0,1,0,0,0,0,1,0,0,0,1],
         [1,0,0,0,2,1,0,0,0,1,0,0,0,4,0,1,1,1,1,0,4,0,1,0,1],
         [1,1,1,1,1,1,0,8,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]],
        
        [[1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,9,1],
         [1,0,0,3,0,0,1,0,0,0,0,0,0,0,0,0,0,4,0,0,0,0,0,0,1],
         [1,0,0,3,0,0,1,0,0,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,1],
         [1,0,0,3,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
         [8,0,0,3,0,0,4,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,4,0,1],
         [1,0,0,3,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
         [1,0,0,3,0,0,3,3,3,3,0,0,3,3,3,3,3,3,3,3,3,3,0,0,1],
         [1,0,0,3,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1],
         [1,0,0,3,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1],
         [1,0,0,0,0,0,0,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1],
         [1,0,0,0,0,4,0,0,0,0,0,0,1,0,0,0,0,0,0,4,0,0,0,0,1],
         [1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1],
         [1,0,0,3,3,3,3,3,3,3,3,3,3,3,0,0,0,3,3,3,3,3,0,0,1],
         [1,0,0,3,0,0,0,0,0,0,0,0,0,3,0,0,0,3,0,0,0,0,0,0,1],
         [1,0,0,3,2,0,0,0,0,0,0,0,0,3,0,0,0,3,0,0,0,0,0,0,1],
         [1,0,0,3,3,3,0,1,0,0,0,0,0,3,0,0,0,3,0,0,0,1,4,0,1],
         [1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,3,0,0,0,1,0,0,1],
         [1,0,0,0,0,0,0,1,0,4,1,0,0,0,0,0,0,3,0,0,0,1,0,2,1],
         [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]]
         ]

wallgroup = pygame.sprite.Group()
virusgroup = pygame.sprite.Group()
playergroup = pygame.sprite.Group()
antibacgroup = pygame.sprite.Group()
dispensergroup = pygame.sprite.Group()
goalgroup = pygame.sprite.Group()
lavagroup = pygame.sprite.Group()

font = pygame.font.Font('freesansbold.ttf',72)
gameovertext = font.render('GAME OVER!',True,(255,0,0))
gameoverrect = gameovertext.get_rect()
gameoverrect.center = (width/2,height/2)

donetext = font.render('GAME FINISHED!',True,(0,255,0))
donerect = donetext.get_rect()
donerect.center = (width/2,height/2)

#########################################

class Goal(pygame.sprite.Sprite):
    def __init__(self,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('goal.png').convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

#########################################

class Dispenser(pygame.sprite.Sprite):
    def __init__(self,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('dispenser.png').convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

#########################################

class Wall(pygame.sprite.Sprite):
    def __init__(self,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('brick.png').convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        
#########################################

class Lava(pygame.sprite.Sprite):
    def __init__(self,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('lava.png').convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

#########################################

class Antibac(pygame.sprite.Sprite):
    def __init__(self,x,y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('paintstain.png').convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

##########################################

class Player(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('patient.png').convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = 64
        self.rect.y = 64
        self.fartx = 0
        self.farty = 0
        self.antibac = 0
    
    def reset(self):
        self.fartx = 0
        self.farty = 0
        self.antibac = 1
    
    def update(self):
        # flytter høyre/venstre og sjekker kollisjon
        self.rect.x += self.fartx
        wall_hitlist = pygame.sprite.spritecollide(self,wallgroup,False)
        if wall_hitlist:
            if self.fartx > 0:
                self.rect.right = wall_hitlist[0].rect.left
            else:
                self.rect.left = wall_hitlist[0].rect.right
        
        #flytter opp/ned og sjekker kollisjon
        self.rect.y += self.farty
        wall_hitlist = pygame.sprite.spritecollide(self,wallgroup,False)
        if wall_hitlist:
            if self.farty > 0:
                self.rect.bottom = wall_hitlist[0].rect.top
            else:
                self.rect.top = wall_hitlist[0].rect.bottom
        
        dispenserhitlist = pygame.sprite.spritecollide(self,dispensergroup,False)
        if dispenserhitlist:
            self.antibac += 5
            dispenserhitlist[0].kill()
        
        goalhitlist = pygame.sprite.spritecollide(self,goalgroup,False)
        if goalhitlist:
            global levelcomplete
            levelcomplete = True
            global levelnumber
            levelnumber += 1
            restart()

#################################################

class Virus(pygame.sprite.Sprite):
    def __init__(self, x, y, fx, fy):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load('virus.png').convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.fartx = fx
        self.farty = fy
    
    def update(self):
        # flytter høyre/venstre og sjekker kollisjon
        self.rect.x += self.fartx
        wall_hitlist = pygame.sprite.spritecollide(self,wallgroup,False)
        if wall_hitlist:
            if self.fartx > 0:
                self.rect.right = wall_hitlist[0].rect.left
            else:
                self.rect.left = wall_hitlist[0].rect.right
                
            self.fartx *= -1
        
        #flytter opp/ned og sjekker kollisjon
        self.rect.y += self.farty
        wall_hitlist = pygame.sprite.spritecollide(self,wallgroup,False)
        if wall_hitlist:
            if self.farty > 0:
                self.rect.bottom = wall_hitlist[0].rect.top
            else:
                self.rect.top = wall_hitlist[0].rect.bottom
            
            self.farty *= -1
        
        #sjekker om viruset treffer ytterkant av skjermen
        if self.rect.right > width or self.rect.x < 0:
            self.fartx = self.fartx * -1
        
        if self.rect.bottom > height or self.rect.y < 0:
            self.farty = self.farty * -1

#################################################

def restart():
    
    global gameover
    global done
    gameover = False
    done = False
    
    for virus in virusgroup:
        virus.kill()
    for dispenser in dispensergroup:
        dispenser.kill()
    for wall in wallgroup:
        wall.kill()
    for lava in lavagroup:
        lava.kill()
    for antibac in antibacgroup:
        antibac.kill()
    for goal in goalgroup:
        goal.kill()
    player.reset()
    
    # MAKING LEVEL
    
    if levelnumber < len(Levels):
        
        for y,rad in enumerate(Levels[levelnumber]):
            for x,value in enumerate(rad):
                if value == 1:
                    wall = Wall(x*32,y*32)
                    wallgroup.add(wall)
                if value == 2:
                    dispenser = Dispenser(x*32,y*32)
                    dispensergroup.add(dispenser)
                if value == 3:
                    lava = Lava(x*32,y*32)
                    lavagroup.add(lava)
                if value == 4:
                    virus = Virus(x*32,y*32,random.randint(1,8),random.randint(1,8))
                    virusgroup.add(virus)
                if value == 8:
                    player.rect.x = x*32
                    player.rect.y = y*32
                if value == 9:
                    goal = Goal(x*32,y*32)
                    goalgroup.add(goal)
    else:
        done = True
            
player = Player()
playergroup.add(player)
restart()

################ MAIN LOOP ###################

while running:
    
    buttonlist = pygame.key.get_pressed()
    
    player.farty = 0
    player.fartx = 0
    
    if buttonlist[pygame.K_UP] and not gameover:
        player.farty = -3
    
    if buttonlist[pygame.K_DOWN] and not gameover:
        player.farty = 3
    
    if buttonlist[pygame.K_RIGHT] and not gameover:
        player.fartx = 3
    
    if buttonlist[pygame.K_LEFT] and not gameover:
        player.fartx = -3
        
    playerhit = pygame.sprite.groupcollide(playergroup,virusgroup,False,False,pygame.sprite.collide_mask)
    if playerhit and not gameover:
        playerdead.play()
        gameover = True
        
    lavahit = pygame.sprite.groupcollide(playergroup,lavagroup,False,False,pygame.sprite.collide_mask)
    if lavahit:
        gameover = True
    
    virushit = pygame.sprite.groupcollide(virusgroup,antibacgroup,True,True,pygame.sprite.collide_mask)
    if virushit:
        virusdead.play()
    
    virusgroup.update()
    playergroup.update()
    antibacgroup.update()
    wallgroup.update()
    dispensergroup.update()
    goalgroup.update()
    lavagroup.update()
    
    screen.fill((255,255,255))
    lavagroup.draw(screen)
    antibacgroup.draw(screen)
    wallgroup.draw(screen)
    goalgroup.draw(screen)
    virusgroup.draw(screen)
    dispensergroup.draw(screen)
    
    if gameover:
        screen.blit(gameovertext,gameoverrect)
    if done:
        screen.blit(donetext,donerect)
        
    playergroup.draw(screen)
    
    clock.tick(30)
    pygame.display.update()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                if player.antibac > 0:
                    dispensersound.play()
                    antibac = Antibac(player.rect.x, player.rect.y)
                    antibacgroup.add(antibac)
                    player.antibac -= 1
            if event.key == pygame.K_n:
                restart()
pygame.quit()